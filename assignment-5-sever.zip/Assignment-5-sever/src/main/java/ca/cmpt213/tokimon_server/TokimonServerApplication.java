package ca.cmpt213.tokimon_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TokimonServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TokimonServerApplication.class, args);
	}

}
