package ca.cmpt213.tokimon_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TokimonServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
